var express=require('express');
var server = express();
var cors = require('cors');
var mysql=require('mysql');
var SendOtp = require('sendotp');
var bodyParser = require('body-parser');
var nodemailer = require('nodemailer');
var PropertiesReader = require('properties-reader');
var mailerOtp=require('./mailOtp.js');

var properties = PropertiesReader('C:\\Users\\Servosys\\WebstormProjects\\Learning\\gmail.properties');

server.use(cors())
server.use(bodyParser.urlencoded({
    extended: true
}));
var sendOtp = new SendOtp('195739AQv1tRuvB75a701e8e');
// server.use(upload.array());
server.use(bodyParser.json());
var OTP;

server.post("/signup", function (req, res) {
    console.log("into signup");
    console.log(req.body);
    // var stringifyJson=JSON.stringify(req.body);
    // console.log("stringifyJson"+stringifyJson);
    var parsedData=req.body;
    console.log("parsedData"+parsedData)

    var keys = Object.keys(parsedData);
    console.log("keys"+keys[0])
    var innerParsedKeys=JSON.parse(keys[0]);
    var innerKeys=Object.keys(innerParsedKeys);
    console.log("innerKeys"+innerKeys.length);
    // console.log(keys.length);
    for(var i=0;i<innerKeys.length;i++){
        console.log("keys---------------"+innerParsedKeys[innerKeys[i]]);
    }
    var con=mailerOtp.getDataBaseConnection(mysql);
    var signupData="insert into userDetails(email,contact,pswd,repeatpswd,status) value('"+innerParsedKeys[innerKeys[0]]+"','"+parseInt(innerParsedKeys[innerKeys[1]])+"','"+innerParsedKeys[innerKeys[2]]+"','"+innerParsedKeys[innerKeys[3]]+"','deactive')";
    con.query(signupData,function (err, result,fields) {
        if (err) throw err;
       console.log("success")

    //
    //
    });
    OTP =Math.floor((Math.random()*10000));
    var fromUser=properties.path().email;
    var emailpassword=properties.path().password;
    //send the mail in case of donator
    mailerOtp.sendMail(fromUser,emailpassword,innerParsedKeys[innerKeys[0]],innerParsedKeys[innerKeys[2]],nodemailer);
    mailerOtp.otpSend(parseInt(innerParsedKeys[innerKeys[1]]),OTP,sendOtp,res)

// sendOtp.verify(parseInt(innerParsedKeys[innerKeys[1]]),OTP,function(error, data, response){
//     console.log(OTP);
// if(data.type == 'success') {
//     console.log("otp verified seccessfully");
//     res.send(data.type);
// }
//    else if(data.type == 'error') {
//         console.log('OTP verification failed');
//         res.send(data.type);
//     }
// });

});
server.post("/login", function (req, res) {
    console.log("into login");
    console.log(req.body);
    // var stringifyJson=JSON.stringify(req.body);
    // console.log("stringifyJson"+stringifyJson);
    var parsedData=req.body;
    console.log("parsedData"+parsedData)

    var keys = Object.keys(parsedData);
    console.log("keys"+keys[0])
    var innerParsedKeys=JSON.parse(keys[0]);
    var innerKeys=Object.keys(innerParsedKeys);
    console.log("innerKeys"+innerKeys.length);
    var con=mailerOtp.getDataBaseConnection(mysql);
    var signupData="insert into userDetails(email,contact,pswd,repeatpswd,status) value('"+innerParsedKeys[innerKeys[0]]+"','"+parseInt(innerParsedKeys[innerKeys[1]])+"','"+innerParsedKeys[innerKeys[2]]+"','"+innerParsedKeys[innerKeys[3]]+"','deactive')";
    con.query(signupData,function (err, result,fields) {
        if (err) throw err;
        console.log("success")

        //
        //
    });


});
server.get("/verify",function(req,res){
    console.log("into verification call");
    var con=mailerOtp.getDataBaseConnection(mysql);
var urlString=req.query;
console.log(urlString);
    var keys=Object.keys(urlString);
var parsedJsonVarification=JSON.parse(keys[0]);
var keys=Object.keys(parsedJsonVarification);
var con=mailerOtp.getDataBaseConnection(mysql);

var verificationQuery="select repeatpswd from userDetails where email='"+parsedJsonVarification[keys[0]]+"' and pswd='"+parsedJsonVarification[keys[1]]+"'";
 var verificationStatus="update userDetails set status='verified' where email='"+parsedJsonVarification[keys[0]]+"'";
    con.query(verificationQuery,function(err,result,fields){
        if(err) throw err;
        // console.log(result[0].repeatpswd);
if(result[0].repeatpswd!==""){
    con.query(verificationStatus,function(err,result,fields){
        if(err) throw err;

        console.log(result)

    });
res.send('1');
}
else{
    res.send('0');
}

    })


})
server.get("/getallUser",function(req,res){
    console.log("into getallUser");
    var con=mailerOtp.getDataBaseConnection(mysql);
    var getAllSequence="select sno,userid,username from userinfo";
    con.query(getAllSequence,function(err,result,fields){
        if(err) throw err;
        console.log(result);
        res.send(JSON.stringify(result));
    })
});
server.get("/hello",function(req,res){
console.log("into get");
// console.log(req.query.jsonString);

    var urlString=req.query.jsonString;
var parsedJson=JSON.parse(urlString);
    var keys = Object.keys(parsedJson);
    // console.log(keys)
   // console.log(parsedJson['userId']);
    var con=mailerOtp.getDataBaseConnection(mysql);

    var insertData="insert into userinfo(userId,userName) value('"+parsedJson[keys[0]]+"','"+parsedJson[keys[1]]+"')";
    con.query(insertData,function (err, result,fields) {
        if (err) throw err;

    });

    var getSequence="SELECT  *  FROM userinfo ORDER BY sno DESC limit 1;";
    con.query(getSequence,function (err, result,fields) {
        if (err) throw err;
        // console.log(fields[2].name);

        console.log(result[0].sno);


        res.send((result[0].sno).toString());
    });



});



server.listen(2224);
console.log("server listening on 2224");


