exports.sendMail=
    function(fromUser,emailpassword,toUser,appPassword,nodemailer){
    var encodeAppPassword="<a href='192.168.1.236:63342/Learning/activation.html?_ijt=h5lgvjpt0f9htrj6jo9kimpuqi'>click here to activate the link</a>";
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        auth: {
            user: fromUser,
            pass: emailpassword
        }
    });

    var mailOptions = {
        from: fromUser,
        to: toUser,
        subject: "verification-mail",
        html: "http://localhost:63342/Learning/activation.html?_ijt=cvvhdhtqt1llo81sqb7eob7b9p",
        text: "Click on the link above to verify your account and your activation code is the password you created at the time of creating account ",
    };

    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });


}

exports.otpSend=function(contact,OTP,sendOtp,res){

    sendOtp.send(contact, "deepanshu",OTP, function (error, data, response) {
        console.log(data);
        if(data.type=='success'){

            res.send(data.type);

        }
        else{
            sendOtp.retry(contact, false, function (error, data, response) {
                console.log(data);
                res.send(data.type);
            });
        }
    });
}
exports.getDataBaseConnection=function(mysql) {

    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "chamasari1234",
        database: "mydb",
    });
    con.connect(function (err) {
        if (err) throw err;
        console.log("Connected!");

    });
    return con;
}