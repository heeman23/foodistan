$(document).ready(function(){
    // $("#logininterface").show();



});

function handleModalsignup(){
    $("#loginSignup").html("Sign Up");
    $("#formData").find("input").val("");
    $("#formData").show();
    $("#signUp").show();
    $("#LoginformData").hide();
    $("#login").hide();

}
function handleModalLogin(){
    $("#loginSignup").html("Login");
    $("#LoginformData").find("input").val("");
    $("#LoginformData").show();
    $("#login").show();
    $("#formData").hide();
    $("#signUp").hide();
}
function signup(){
    // $('#logininterface').removeClass("hide");
    var map={};
    var flag=1;
$("#formData").find("input").each(function(){
    if($(this).val()===""){
        $(this).addClass("mandatory");
        flag=0;

    }
    else {
        $(this).removeClass("mandatory");
        map[$(this).attr("id")] = $(this).val();
    }

})
    if(flag===0){
    return false;
    }
    else {
        alert(JSON.stringify(map));
        var stringfyJson = JSON.stringify(map);
        $.ajax({
            type: "post",
            // dataType: "JSON",

            async: false,
            url: "http://192.168.1.235:2224/signup",
            crossDomain: true,
            data: stringfyJson,

            success: function (data) {
                alert(data)
                if (data === 'error') {
                    alert("signin error")
                }
                else {
                    $(".modal-footer").find("div").removeClass("hidden");
                    $("#signupinterface").modal("hide");



                }

            },
            error: function (jqXHR, error) {
                // alert(jqXHR)
                console.log(error);
            },

        });

    }
}
function login(){
    // $('#logininterface').removeClass("hide");
    var map={};
    var flag=1;
    $("#LoginformData").find("input").each(function(){
        if($(this).val()===""){
            $(this).addClass("mandatory");
            flag=0;

        }
        else {
            $(this).removeClass("mandatory");
            map[$(this).attr("id")] = $(this).val();
        }

    })
    if(flag===0){
        return false;
    }
    else {
        alert(JSON.stringify(map));
        var stringfyJson = JSON.stringify(map);
        $.ajax({
            type: "post",
            // dataType: "JSON",

            async: false,
            url: "http://192.168.1.235:2224/login",
            crossDomain: true,
            data: stringfyJson,

            success: function (data) {
                alert(data)


            },
            error: function (jqXHR, error) {
                // alert(jqXHR)
                console.log(error);
            },

        });

    }
}