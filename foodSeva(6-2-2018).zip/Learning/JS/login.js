$(document).ready(function(){
    // $("#logininterface").show();



});

function handleModalsignup(){
    $("#loginSignup").html("Sign Up");
    $("#formData").find("input").val("");
    $("#formData").show();
    $("#signUp").show();
    $("#LoginformData").hide();
    $("#login").hide();
$("#verifyForm").hide();
$("#verifyOTP").hide();
    $(".modal-footer").find("div[class='alert-success']").addClass("hidden");
}
function handleModalLogin(){
    $("#loginSignup").html("Login");
    $("#LoginformData").find("input").val("");
    $("#LoginformData").show();
    $("#login").show();
    $("#formData").hide();
    $("#signUp").hide();
    $("#verifyForm").hide();
    $("#verifyOTP").hide();
    $(".modal-footer").find("div[class='alert-success']").addClass("hidden");
}


//sign up for new user
function signup(){
    // $('#logininterface').removeClass("hide");
    var map={};
    var flag=1;
$("#formData").find("input[type!='checkbox']").each(function(){
    if($(this).val()===""){
        $(this).addClass("mandatory");
        flag=0;

    }
    else {
        $(this).removeClass("mandatory");
        map[$(this).attr("id")] = $(this).val();
    }

})
    if(flag===0){
    return false;
    }
    else {
        // alert(JSON.stringify(map));
       var checkboxval= $("#formData").find("input[type='checkbox']").prop("checked");
       var checkboxid= $("#formData").find("input[type='checkbox']").attr("id");
        map[checkboxid]=checkboxval;
        var stringfyJson = JSON.stringify(map);
        $.ajax({
            type: "post",
            // dataType: "JSON",

            async: false,
            url: "http://192.168.1.235:2224/signup",
            crossDomain: true,
            data: stringfyJson,

            success: function (data) {
                alert(data);
                var JsonData=JSON.parse(data);

                if (JsonData[0] === '0') {
                    alert("signin error")
                    $("#signupinterface").modal("hide");
                }
               else if (JsonData[0] === '1') {
                    alert("succesful,check your email for verification")
                    $("#signupinterface").modal("hide");

                }
                else if(JsonData[0]==='2'){
alert('succesful,use OTP to verify your phone number');
                    $(".modal-footer").find("div").removeClass("hidden");
                    $("#formData").hide();
                    $("#signUp").hide();
                    $("#verifyForm").show();
                    $("#verifyOTP").show();
                    $("#loginSignup").html("Verify OTP");
                    $(".modal-footer").find("div[class='alert-success']").addClass("hidden");
localStorage.setItem("otp",JsonData[1]);
localStorage.setItem("email",$("#email").val());
                    var date = new Date();
                    var startTime = date.getTime();
                    var minutes = date.getMinutes() + 1;
                    date.setMinutes(minutes);
                    $("#timer").countdown(date)
                        .on('update.countdown', function(event) {
                            $(this).text(
                                event.strftime('%H:%M:%S')
                            );
                        })
                        .on('finish.countdown', function(event) {
                            alert("Sorry, Your time is up!");
                            $scope.quizSubmit();
                        });
                }
                else {
                    alert("signin error")
                    $("#signupinterface").modal("hide");

                }

            },
            error: function (jqXHR, error) {
                // alert(jqXHR)
                console.log(error);
            },

        });

    }
}
//verification of OTP
function verify(){
var userOtp=$("#otpverification").val();
if(userOtp===localStorage.getItem("otp")){
    $.ajax({
        type: "get",
        // dataType: "JSON",

        async: false,
        url: "http://192.168.1.235:2224/updatestatus",
        crossDomain: true,
        data: localStorage.getItem("email"),

        success: function (data) {
            alert(data);
            if(data==='1'){

                window.open("http://localhost:63342/Learning/home.html?_ijt=g8tc2d53o1pu4i7iu9g2bdsa97");

            }
            // if (data === '0') {
            //     alert("verification failed")
            // }
            // else {
            //     alert("account verified,Please login");
            //     window.close();
            //     opener.open("http://localhost:63342/Learning/login.html?_ijt=85l3khnsuesi6s2c8f3upl75t2");
            //
            //
            //
            // }

        },
        error: function (jqXHR, error) {
            // alert(jqXHR)
            console.log(error);
        },

    });

}
else{
    alert("OTP not matched")
}

}
//login for a user
function login(){
    // $('#logininterface').removeClass("hide");
    var map={};
    var flag=1;
    $("#LoginformData").find("input").each(function(){
        if($(this).val()===""){
            $(this).addClass("mandatory");
            flag=0;

        }
        else {
            $(this).removeClass("mandatory");
            map[$(this).attr("id")] = $(this).val();
        }

    })
    if(flag===0){
        return false;
    }
    else {
        alert(JSON.stringify(map));
        var stringfyJson = JSON.stringify(map);
        $.ajax({
            type: "post",
            // dataType: "JSON",

            async: false,
            url: "http://192.168.1.235:2224/login",
            crossDomain: true,
            data: stringfyJson,

            success: function (data) {
                debugger;
                alert(data);

                if(data==='0'){
                    alert("invalid user");
                }
                else if(data==='1'){
                    $("#signupinterface").modal("hide");
                    window.open('http://localhost:63342/Learning/home.html?_ijt=g8tc2d53o1pu4i7iu9g2bdsa97');
                }
                else{
                    // window.close();

                    alert("You haven't verified your email,your account will get deactive in 2 days");
                    $("#signupinterface").modal("hide");
                    window.open('http://localhost:63342/Learning/home.html?_ijt=g8tc2d53o1pu4i7iu9g2bdsa97');
                }


            },
            error: function (jqXHR, error) {
                // alert(jqXHR)
                console.log(error);
            },

        });

    }
}