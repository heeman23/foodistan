var express=require('express');
var server = express();
var cors = require('cors');
var mysql=require('mysql');
var SendOtp = require('sendotp');
var bodyParser = require('body-parser');
var nodemailer = require('nodemailer');
var PropertiesReader = require('properties-reader');
var mailerOtp=require('./mailOtp.js');

var properties = PropertiesReader('C:\\Users\\Servosys\\WebstormProjects\\Learning\\gmail.properties');

server.use(cors())
server.use(bodyParser.urlencoded({
    extended: true
}));
var sendOtp = new SendOtp('195739AQv1tRuvB75a701e8e');
// server.use(upload.array());
server.use(bodyParser.json());
var OTP;

//sign up for new user(verification by email and otp)

server.post("/signup", function (req, res) {
    console.log("into signup");
    console.log(req.body);
    // var stringifyJson=JSON.stringify(req.body);
    // console.log("stringifyJson"+stringifyJson);
    var parsedData=req.body;
    console.log("parsedData"+parsedData)

    var keys = Object.keys(parsedData);
    console.log("keys"+keys[0])
    var innerParsedKeys=JSON.parse(keys[0]);
    var innerKeys=Object.keys(innerParsedKeys);
    console.log("innerKeys"+innerKeys.length);
    // console.log(keys.length);
    for(var i=0;i<innerKeys.length;i++){
        console.log("keys---------------"+innerParsedKeys[innerKeys[i]]);
    }
    var con=mailerOtp.getDataBaseConnection(mysql);
    var signupData="insert into userDetails(email,contact,pswd,repeatpswd,status) value('"+innerParsedKeys[innerKeys[0]]+"','"+parseInt(innerParsedKeys[innerKeys[1]])+"','"+innerParsedKeys[innerKeys[2]]+"','"+innerParsedKeys[innerKeys[3]]+"','deactive')";
    con.query(signupData,function (err, result,fields) {
        if (err) throw err;
       console.log("success")

    //
    //
    });
    if(innerParsedKeys[innerKeys[4]]===true) {
        OTP = Math.floor((Math.random() * 10000));
        mailerOtp.otpSend(parseInt(innerParsedKeys[innerKeys[1]]), OTP, sendOtp, res);

    }
    else {
        var fromUser = properties.path().email;
        var emailpassword = properties.path().password;
        //send the mail in case of donator
        mailerOtp.sendMail(fromUser, emailpassword, innerParsedKeys[innerKeys[0]], innerParsedKeys[innerKeys[2]], nodemailer,res);
    }
// sendOtp.verify(parseInt(innerParsedKeys[innerKeys[1]]),OTP,function(error, data, response){
//     console.log(OTP);
// if(data.type == 'success') {
//     console.log("otp verified seccessfully");
//     res.send(data.type);
// }
//    else if(data.type == 'error') {
//         console.log('OTP verification failed');
//         res.send(data.type);
//     }
// });

});





//loginService for a user
server.post("/login", function (req, res) {
    console.log("into login");
    console.log(req.body);
    // var stringifyJson=JSON.stringify(req.body);
    // console.log("stringifyJson"+stringifyJson);
    var parsedData=req.body;
    console.log("parsedData"+parsedData)

    var keys = Object.keys(parsedData);
    console.log("keys"+keys[0])
    var innerParsedKeys=JSON.parse(keys[0]);
    var innerKeys=Object.keys(innerParsedKeys);
    console.log("innerKeys"+innerKeys.length);
    var con=mailerOtp.getDataBaseConnection(mysql);
    // var signupData="insert into userDetails(email,contact,pswd,repeatpswd,status) value('"+innerParsedKeys[innerKeys[0]]+"','"+parseInt(innerParsedKeys[innerKeys[1]])+"','"+innerParsedKeys[innerKeys[2]]+"','"+innerParsedKeys[innerKeys[3]]+"','deactive')";
    // con.query(signupData,function (err, result,fields) {
    //     if (err) throw err;
    //     console.log("success")
    // });
var loginData="select status from userDetails where email='"+innerParsedKeys[innerKeys[0]]+"' and pswd='"+innerParsedKeys[innerKeys[1]]+"'";
con.query(loginData,function(err,result,fields){
    console.log(err);
    console.log(result[0]);
    if(result[0]===undefined){
        // console.log("0");
        res.send("0");

    }
    // if(err==null) {
    //     console.log(err);
    //     res.send("0");
    // }
// console.log(result[0].status);
else if(result[0].status==="active"){
    res.send("1");
}
else {
        res.send("2");
    }

});

});






// verify email
server.get("/verify",function(req,res) {
    console.log("into verification call");
    var con = mailerOtp.getDataBaseConnection(mysql);
    var urlString = req.query;
    console.log(urlString);
    var keys = Object.keys(urlString);
    var parsedJsonVarification = JSON.parse(keys[0]);
    var keys = Object.keys(parsedJsonVarification);
    var con = mailerOtp.getDataBaseConnection(mysql);

    var verificationQuery = "select repeatpswd from userDetails where email='" + parsedJsonVarification[keys[0]] + "' and pswd='" + parsedJsonVarification[keys[1]] + "'";
    var verificationStatus = "update userDetails set status='active' where email='" + parsedJsonVarification[keys[0]] + "'";
    con.query(verificationQuery, function (err, result, fields) {
        if (err) throw err;
        // console.log(result[0].repeatpswd);
        if (result[0].repeatpswd !== "") {
            con.query(verificationStatus, function (err, result, fields) {
                if (err) throw err;

                console.log(result)

            });
            res.send('1');
        }
        else {
            res.send('0');
        }

    })
});




//verify otp and update status
    server.get("/updatestatus",function(req,res){
        console.log("into update status call");
        var con=mailerOtp.getDataBaseConnection(mysql);
        var urlString=req.query;
        console.log(urlString);
        var keys = Object.keys(urlString);
console.log(keys[0]);
        var verificationStatus="update userDetails set status='active' where email='"+keys[0]+"'";
        con.query(verificationStatus,function(err,result,fields){
            if(err) throw err;
            // console.log(result[0].repeatpswd);
res.send("1");

        })


    });


server.listen(2224);
console.log("server listening on 2224");











